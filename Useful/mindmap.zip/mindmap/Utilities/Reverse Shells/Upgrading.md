Upgrade through python / python3:
```
python3 -c 'import pty; pty.spawn("/bin/bash")'
```
