## Important Nmap options

Disables port scanning:
```
-sn
```

Disables ICMP Echo Requests:
```
-Pn
```

Disables DNS Resolution:
```
-n
```

Performs the ping scan by using ICMP Echo Requests against the target:
```
-PE
```

Shows all packets sent and received:
```
--packet-trace
```

Displays the reason for a specific result:
```
--reason
```

Disables ARP Ping Requests:
```
--disable-arp-ping
```

Scans the specified top ports that have been defines as most frequent:
```
--top-ports=<num>
```

Scan all ports:
```
-p-
```

Scans top 100 ports:
```
-F
```

Performs a TCP SYN-Scan:
```
-sS
```

Performs a TCP ACK-Scan:
```
-sA
```

Performs a UDP Scan:
```
-sU
```

Scans the discovered services for their versions:
```
-sV
```

Perform a script scan with default scripts:
```
-sC
```

Perform a script scan using the specified scripts:
```
--script <script>
```

Performs an OS detection scan:
```
-O
```

Performs OS detection, service detection, and traceroute scans:
```
-A
```

Sets the number of random decoys that will be used to scan the target:
```
-D RND:5
```

Specifies the network interface that is used for the scan:
```
-e
```

Specifies the source IP address for the scan:
```
-S <ip>
```

Specifies the source port for the scan:
```
-g
```

DNS resolution is performed using a specified name server:
```
--dns-server <name server ip>
```

### Output options
Stores the results in all available formats starting with the supplied name:
```
-oA <file name>
```

Stores the results in normal format with the supplied name:
```
-oN <file name>
```

Stores the results in grepable format with the supplied name:
```
-oG <file name>
```

Stores the results in XML format with the supplied name:
```
-oX <file name>
```

### Performance options
Sets the number of retries for scans of specific ports:
```
--max-retries <num>
```

Displays scan's status every 5 seconds:
```
--stats-every=5s
```

Displays verbose output during the scan:
```
-v/-vv/-vvv
```

Sets the specified time value as initial RTT timeout:
```
--initial-rtt-timeout 50ms
```

Sets the specified time value as maximum RTT timeout:
```
--max-rtt-timeout 100ms
```

Sets the number of packets that will be sent simultaneously:
```
--min-rate 300
```

Specifies the specific timing template:
```
-T <0-5>
```