Directory fuzzing:
```
ffuf -w <wordlist>:FUZZ -u http://<target>/FUZZ
```

Extension fuzzing:
```
ffuf -w /usr/share/wordlists/SecLists/Discovery/Web-Content/web-extensions.txt:FUZZ -u http://<target>/indexFUZZ
```

Page fuzzing:
```
ffuf -w <wordlist>:FUZZ -u http://<target>/FUZZ<discovered extension>
```

Recursive fuzzing:
```
ffuf -w <wordlist>:FUZZ -u http://<target>/FUZZ -recursion -recursion-depth <depth (3 or less recommended)> -e <discovered extension> -v
```

Subdomain fuzzing:
```
ffuf -w <wordlist>:FUZZ -u http://FUZZ.<target>/
```

VHost fuzzing:
```
ffuf -w <wordlist>:FUZZ -u http://<target>/ -H "Host: FUZZ.<target>" -fs <size discovered after scanning without this parameter>
```

GET parameter fuzzing:
```
ffuf -w /usr/share/wordlists/SecLists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u <url of discovered page>?FUZZ=test -fs <size discovered after scanning without this parameter>
```

POST parameter fuzzing:
```
ffuf -w /usr/share/wordlists/SecLists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u <url of discovered page> -X POST -d 'FUZZ=test' -H 'Content-Type: application/x-www-form-urlencoded' -fs <size discovered after scanning without this parameter>
```

GET value fuzzing:
```
ffuf -w <wordlist>:FUZZ -u <url of discovered page>?<discovered parameter>=FUZZ -fs <size discovered after scanning without this parameter>
```

POST value fuzzing:
```
ffuf -w <wordlist>:FUZZ -u <url of discovered page> -X POST -d '<discovered parameter>=FUZZ' -H 'Content-Type: application/x-www-form-urlencoded' -fs <size discovered after scanning without this parameter>
```

One liner to make a sequence of values wordlist:
```
for i in $(seq <start> <end>); do echo $i >> <output>.txt; done
```

Curl a POST request:
```
curl <target> -X POST -d '<parameter>=<value>' -H 'Content-Type: application/x-www-form-urlencoded'
```

