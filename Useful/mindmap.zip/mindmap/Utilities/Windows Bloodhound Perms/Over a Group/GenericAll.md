Allows attacker to directly modify group membership of the group:

Add self to target group:
```
net rpc group addmem "<target group>" "<user to add>" -U "<DOMAIN>"/"<user with permission>"%"<password>" -S "<domain controller ip>"
```

