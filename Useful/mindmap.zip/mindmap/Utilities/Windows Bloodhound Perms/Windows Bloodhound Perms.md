[[Starting Bloodhound]]

## Over a Group
[[AddSelf]]
[[Utilities/Windows Bloodhound Perms/Over a Group/WriteOwner|WriteOwner]]
[[Utilities/Windows Bloodhound Perms/Over a Group/GenericAll|GenericAll]]


## Over a User
[[ForceChangePassword]]
[[Utilities/Windows Bloodhound Perms/Over a User/GenericAll]]
[[GenericWrite]]
[[ReadGMSAPassword]]
[[Utilities/Windows Bloodhound Perms/Over a User/WriteOwner|WriteOwner]]
[[WriteSPN]]
