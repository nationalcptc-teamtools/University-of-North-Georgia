
Netexec ldap bloodhound file queries:
```
nxc ldap <domain> -u <username> -p <password> --bloodhound --collection All --dns-server <ip>
```

If LDAP STATUS_NOT_SUPPORTED on previous command:
```
bloodhound-python -ns <ip> -u "<username>" -p "<password>" -d "<domain>" -c All
```

Bloodhound start:
```
sudo neo4j start &
bloodhound
```
