Find all certificate templates:
```
certipy-ad find -dc-ip <ip> -u <user> -p <password>
```

Find all vulnerable certificate templates:
```
certipy-ad find -dc-ip <ip> -u <user> -p <password> -vulnerable
```

Look for vulnerable certificates at the bottom of the following output:
```
cat <timestamp from output of last command>_Certipy.txt
```

Then look [here](https://github.com/ly4k/Certipy/wiki) for the corrosponding wiki entry

