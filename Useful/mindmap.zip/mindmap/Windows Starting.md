Port 53 open:
[[DNS - 53]]

Given credentials:
[[Windows Bloodhound Perms]]

Port 80 / 443 open:
[[Web Exploitation]]

Port 445 open:
[[SMB - 445]]

Port 3306 open:
[[MySQL - 3306]]

[[Windows PrivEsc Checklist]]