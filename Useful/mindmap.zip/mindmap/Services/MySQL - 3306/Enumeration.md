
## Bad shell
Since it's a bad shell, use inline command execution

View database names:
```
mysql -u <username> -p<password> -h <presumably localhost> -e 'SELECT schema_name FROM information_schema.SCHEMATA;'
```

To view tables within a specified database:
```
mysql -u <username> -p<password> -h <presumably localhost> -e 'SELECT table_name FROM information_schema.TABLES WHERE table_schema = "<specified database name>";'
```

Dump all data from a specified table in an easy to read way:
```
mysql -u <username> -p<password> -h <presumably localhost> -e 'USE <target database>;SELECT * FROM <target table>;' -E
```

