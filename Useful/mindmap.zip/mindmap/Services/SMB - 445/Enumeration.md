List shares anonymously:
```
smbclient -N -L //<ip address>
```

List shares using username and password:
```
smbclient -L //<ip address> -U '<username>%<password>'
```

Open an smbclient session of a discovered share:
```
smbclient //<ip address>/<share name> -U '<username>%<password>'
```

