Attempt a zone transfer attack to leak records
```
dig @<ip> <FQDN> AXFR
```
