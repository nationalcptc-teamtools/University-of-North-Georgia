
Port 80 / 443 open:
[[Web Exploitation]]

[[Kubernetes - 10250]]
[[MySQL - 3306]]

[[Linux PrivEsc Checklist]]