Following scenario came from the Certificate HTB box where I had a Powershell reverse shell and leaked database credentials through a database configuration file and wanted to dump the database to a web-accessible location

MySQL hosted through xampp:
```
"C:\\xampp\\mysql\\bin\\mysqldump.exe" -u <username> -p<password> <database name> > <full path of extraction destination>
```