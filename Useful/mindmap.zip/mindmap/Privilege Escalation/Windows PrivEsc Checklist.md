Check privileges:
```
whoami /priv
```

[[Certipy ESCs]]
[[SeManageVolumePrivilege]]
[[MySQL Dump]]
[[DPAPI]]
