Check superuser permissions:
```
sudo -l
```

Check if you're in a container:
```
ls -l /.dockerenv
```

Check running processes:
```
ss -plunt
```

[[MySQL - 3306]]
