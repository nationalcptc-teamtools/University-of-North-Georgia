Add to /etc/hosts one-liner:
```
sudo sh -c 'echo "<ip> <domain>" >> /etc/hosts'
```

Base nmap scan to be compatible with Zenmap:
```
nmap -A -T4 -vvv <ip> -oX <FQDN>.xml
```
More scans in [[Nmap Cheatsheet]]

Windows OS:
[[Windows Starting]]

Linux OS:
[[Linux Starting]]
