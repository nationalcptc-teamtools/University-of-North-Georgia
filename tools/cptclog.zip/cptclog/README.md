# cptclog — transparent terminal evidence logger (Windows + Linux)

`cptclog` wraps your normal shell. The terminal looks and behaves exactly as it
always does (tab completion, arrow keys, colours, vim, less, ssh, Ctrl+C, resize),
but every command you **actually execute** is saved with:

- the exact command line as the shell ran it (not your keystrokes/typos/edits)
- the time it started and finished
- the working directory and `user@host` it ran on
- the exit code
- the output, with colour codes and progress-bar redraws stripped
- **file edits**: when you open a file in nano/vim/vi/nvim/micro/emacs (or
  `sudo nano`, `sudoedit`, `notepad` on Windows) the file is snapshotted before and
  compared after, and a unified diff of what you changed is attached to that entry
  (green = added, red = removed in the HTML; a ```diff block in the markdown).

Logs are written as a hash-chained `.jsonl` file, a plain `.md` transcript you can
just `cat`, and an `.html` report. If a saved
entry is edited after the fact (redacting, "fixing" output, …) the report flags it
in **red**, and `render --against ORIGINAL.jsonl` colours exactly what changed
(green = added, red = removed).

Only dependency: Python 3.8+. Windows additionally needs `pywinpty`.

```
cptclog/
  cptclog.py   entry point (record / render / verify / hook)
  hooks.py     shell integration snippets (bash, zsh, PowerShell)
  recorder.py  marker parser, output cleaning, hash-chained JSONL writer
  render.py    HTML report (integrity check + diff colouring)
  logs/        created automatically: <host>_<timestamp>.jsonl / .md / .html
```

## Quick start

### Linux / macOS (bash or zsh)

```bash
python3 cptclog.py                # uses $SHELL (bash or zsh)
python3 cptclog.py --shell bash   # or force one
# ... work normally ...
exit                              # finishes the log and writes the HTML report
```

### Windows (PowerShell 5.1 or PowerShell 7)

Needs Windows 10 1809+ / Windows 11 (ConPTY). Windows Terminal recommended, the
classic console window works too.

```powershell
pip install pywinpty
python cptclog.py                  # pwsh if installed, otherwise Windows PowerShell
python cptclog.py --shell powershell
# ... work normally ...
exit
```

Handy alias so it's one word during the competition:

```powershell
# PowerShell profile
function rec { python C:\tools\cptclog\cptclog.py @args }
```
```bash
# ~/.bashrc
alias rec='python3 ~/tools/cptclog/cptclog.py'
```

### Options

```
python cptclog.py [record] [--shell bash|zsh|powershell|pwsh] [--logdir DIR] [-q]
python cptclog.py render  LOG.jsonl [-o OUT.html] [--against ORIGINAL.jsonl] [--md]
python cptclog.py verify  LOG.jsonl
python cptclog.py hook    bash|zsh|powershell
```

`-q` suppresses the one-line "[cptclog] recording …" banners at start and exit so
the session is 100 % indistinguishable from a normal shell.

## What you get

`logs/<host>_<YYYYmmdd_HHMMSS>.jsonl` — one JSON object per line:

```json
{"type":"session","started":"2026-10-13T20:35:16.258+00:00","shell":"bash","user":"root","hostname":"kali","os":"Linux-..."}
{"type":"cmd","seq":4,"started":"...20:35:20.773","finished":"...20:35:20.784","host":"root@kali","cwd":"/tmp",
 "command":"id","exit":0,"output":"uid=0(root) gid=0(root) groups=0(root)",
 "prev":"8dd8fc73...","hash":"013edbb6..."}
{"type":"end","finished":"...","commands":5}
```

`logs/<host>_<timestamp>.md` — plain markdown transcript, appended **live** as each
command finishes, so during a session you can just `cat` it or `tail -f` it from
another terminal:

```
## 4  20:43:03  root@kali:/tmp  exit 0

```
$ id
uid=0(root) gid=0(root) groups=0(root)
```
```

(`render LOG.jsonl --md` rebuilds it from the jsonl if you ever need to.)

`logs/<host>_<timestamp>.html` — dark, searchable report. Each command is a card
with time, duration, host, cwd, exit code (red left bar if non-zero), command and
output. A filter box and an "only non-zero exit" toggle are at the top.
Regenerate it any time with `render`.

JSONL is deliberate: `jq`, Python, or your finding tracker can read it directly, e.g.

```bash
jq -r 'select(.type=="cmd") | "\(.started) \(.host):\(.cwd) $ \(.command)"' logs/kali_*.jsonl
```

## Integrity / "what changed" colouring

Every `cmd` entry carries `prev` (previous entry's hash) and `hash`
(SHA-256 over the entry's fields + `prev`). That makes the file a hash chain:

- `python cptclog.py verify LOG.jsonl` — exits 0 if nothing was touched, otherwise
  lists the edited entry numbers and exits 1.
- `render` always runs the same check. Edited entries get a red border and a
  **MODIFIED AFTER CAPTURE** tag, plus a red banner at the top of the report.
- If you intentionally edit a copy (e.g. redact a password before it goes in the
  report), keep the original and run
  `python cptclog.py render EDITED.jsonl --against ORIGINAL.jsonl`.
  Every changed line in the command or output is coloured: green = added,
  red + strikethrough = removed.

This is a tamper-*evidence* mechanism, not tamper-*proof*: someone with the file
could recompute the chain. If you need that, sign the finished `.jsonl`
(`gpg --detach-sign`) or hash it and record the hash in your notes at the end
of the engagement.

## How it works

1. `cptclog.py` starts your shell inside a pseudo-terminal it controls
   (`pty` on Linux/macOS, ConPTY via `pywinpty` on Windows) and puts your real
   terminal in raw mode. Keystrokes go straight to the shell; whatever the shell
   prints goes straight to your screen. That's why everything behaves normally.
2. The shell is started with a small integration hook loaded **after** your
   normal startup files (`~/.bashrc`, `~/.zshrc`, `$PROFILE`), so your aliases,
   prompt and PSReadLine config are untouched. The hook makes the shell emit
   invisible escape sequences (`ESC ] 633 ; … BEL`, the same family VS Code and
   iTerm2 use) at four moments:

   | marker | meaning | bash / zsh | PowerShell |
   |---|---|---|---|
   | `A;cwd;user@host` | prompt about to be drawn | `PROMPT_COMMAND` / `precmd` | `prompt` function |
   | `B` | prompt finished, user typing | appended to `PS1` | `prompt` function |
   | `C;command` | Enter pressed, command starting | `PS0` + `history 1` / `preexec` | — |
   | `D;exit` | command finished | `PROMPT_COMMAND` / `precmd` | — |
   | `E;command;start;end;ok;exit` | command finished (reported at next prompt) | — | `Get-History -Count 1` |

   The command text is base64-encoded inside the marker so quotes, Unicode and
   semicolons can't break it.
3. `recorder.py` watches the output stream, removes the markers before anything
   is written to your screen, and uses them to slice the stream: text between
   `C` and `D` (or after `B`, minus the echoed input line, on PowerShell) is the
   output of that command. Because the command text comes from the shell's own
   history, you get what was executed — after tab-completion, history recall and
   line editing — not raw keystrokes.
4. Output is cleaned: ANSI colour/cursor sequences are removed and `\r` redraws
   (progress bars, spinners) collapse to their final state. Then the entry is
   hashed, chained to the previous one and appended to the `.jsonl` immediately,
   so a crash or a killed terminal loses at most the command in flight.
5. On exit the `.html` report is rendered. `render`/`verify` rebuild or check it
   later.

## File edits (nano / vim / …)

The hook replaces `nano`, `vim`, `vi`, `nvim`, `micro`, `emacs`, `pico`, `joe`
(whichever are installed), `sudo <editor>`, `sudoedit`, and on Windows `notepad`
with thin wrapper functions. The wrapper:

1. copies every file argument that exists (and is < 2 MB) to a temp dir,
2. runs the real editor exactly as you typed it (`command nano …`),
3. compares each file afterwards and, if it changed, sends before/after contents
   to the recorder in an invisible marker. The recorder stores a unified diff on
   the entry (`"changes": [{"path","status","diff"}]`, status = created /
   modified / deleted; binary files just get a size note).

The editor's screen output itself is not kept (it would be cursor-movement
soup); the entry shows `(interactive program - screen output not kept)` plus
the diff, which is the evidence you actually want.

Not caught: edits made by a command the wrapper doesn't know (`sed -i`,
`echo … > file`, `tee`, editors started from inside another program). The
command line is still logged, so the action is on record, just not the diff.

## Tips for CPTC

- **Notes in the log**: just run `echo "NOTE: got root on web01 via sudo find"`.
  It's logged like any command, timestamped, and shows up in the filter.
  (A bare `# comment` line is *not* logged in bash, because bash never executes it.)
- **Remote shells**: when you `ssh` somewhere, the whole ssh session is captured as
  the output of the `ssh` command. To get per-command entries on the remote box
  too, paste the hook into the remote shell:
  `python cptclog.py hook bash` prints it; paste it at the remote prompt. The
  markers travel back through ssh and the recorder picks them up, with the
  remote `user@host` and cwd on each entry. Works through any transparent
  channel (ssh, nc shells after `script -q /dev/null`, etc.).
- **One session per target / per tester** keeps logs tidy; file names include
  host and start time.
- Interactive full-screen programs (vim, htop, less) are logged as one entry whose
  output is the screen scribble — that's expected; the evidence is the command
  and the time, not the TUI.
- `sudo` password prompts: the typed password is never echoed by the terminal, so
  it does not end up in the log. Passwords typed on a command line (`-p pass`)
  **do** — redact a copy and keep the original (see integrity section).

## Limitations

- Supported shells: bash, zsh (tested on both; Kali's default zsh config works
  as-is), Windows PowerShell 5.1, PowerShell 7. `cmd.exe`
  and fish have no hook; you can still run them *inside* a recorded shell, their
  whole session becomes one entry.
- PowerShell has no "command is starting" hook, so the start/end times come from
  PowerShell's own history (`StartExecutionTime`/`EndExecutionTime`) and the
  echoed input line is stripped heuristically. Very long commands that wrap
  across lines in the console may leave part of the echo in the output.
- On Windows the terminal must support ConPTY (Win10 1809+). If `pywinpty`
  fails to install, use a recent Python from python.org (it ships wheels for
  3.8–3.13).
- macOS works with the Linux instructions (bash or zsh).
- Inside a recorded zsh session the `%` end-of-line marker (printed when a
  command's output has no trailing newline) is turned off so it doesn't pollute
  captured output; nothing else about your zsh setup is changed.
