# cptclog — terminal evidence logger

Wraps your shell and silently records every command you run — command line, time, directory, `user@host`, exit code, and cleaned output. File edits in nano/vim/etc. are saved as before/after diffs. Works on Linux, macOS, and Windows.

Logs are written three ways: `.jsonl` (machine-readable, tamper-evident), `.md` (plain transcript you can `cat`), and `.html` (searchable report).

Only needs Python 3.8+ (Windows also needs `pip install pywinpty`).

## Run it

**Linux / macOS:**
```bash
python3 cptclog.py      # work normally, then:
exit                    # finishes the log + writes the HTML report
```

**Windows (PowerShell):**
```powershell
pip install pywinpty
python cptclog.py
exit
```

Optional one-word alias:
```bash
alias rec='python3 ~/tools/cptclog/cptclog.py'
```

## Commands

```
python cptclog.py                       # start recording
python cptclog.py render LOG.jsonl       # rebuild the HTML report
python cptclog.py verify LOG.jsonl       # check nothing was edited after capture
python cptclog.py hook bash|zsh|powershell   # print the shell hook (for remote shells)
```

Logs land in `logs/<host>_<timestamp>.{jsonl,md,html}`.

## Good to know

- **Add notes to the log:** `echo "NOTE: got root on web01 via sudo find"` — timestamped like any command.
- **Remote shells:** after you `ssh` in, paste the output of `cptclog.py hook bash` at the remote prompt to get per-command logging there too.
- **Integrity:** every entry is hash-chained. `verify` flags anything edited after the fact; the HTML report marks tampered entries in red. If you redact a copy (e.g. a password), keep the original and run `render EDITED.jsonl --against ORIGINAL.jsonl` to show exactly what changed.
- **Passwords:** `sudo` prompts aren't echoed, so they're never logged. Passwords on a command line (`-p pass`) *are* — redact a copy.
- **Not captured as diffs:** edits via `sed -i`, `echo > file`, `tee`, or editors cptclog doesn't know. The command itself is still logged.
- **Supported shells:** bash, zsh, PowerShell 5.1/7. `cmd.exe` and fish run fine *inside* a recorded shell but become one entry.
